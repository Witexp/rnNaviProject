export const LOAD_POSTS = 'LOAD_POSTS'
export const TOGGLE_BOOKED = 'TOGGLE_BOOKED'
export const REMOVE_POST = 'REMOVE_POST'
export const ADD_POST='ADD_POST'